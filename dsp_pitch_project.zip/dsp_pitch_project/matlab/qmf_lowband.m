function xl = qmf_lowband(x, h, levels)
%QMF_LOWBAND  Octave tree: repeat (H0 filtering, decimation by 2) `levels` times.
%   Group delay (N-1)/2 samples is compensated by an integer shift.
x = x(:);
D = floor((numel(h)-1)/2);
for k = 1:levels
    y = conv(x, h(:));
    y = y(D+1 : D+numel(x));
    x = y(1:2:end);
end
xl = x;
end
