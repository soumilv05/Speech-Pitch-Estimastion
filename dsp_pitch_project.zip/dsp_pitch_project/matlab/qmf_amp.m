function Hr = qmf_amp(h, w)
%QMF_AMP  Amplitude response of a symmetric even-length FIR at frequencies w (rad/sample).
N = numel(h); M = N/2; h = h(:);
n = 0:M-1;
A = 2*cos(w(:) * ((N-1)/2 - n));
Hr = A * h(1:M);
end
