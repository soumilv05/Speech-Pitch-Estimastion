function p = pct90(x)
%PCT90  90th percentile with linear interpolation (same as numpy.percentile). No toolbox needed.
x = sort(x(:));
n = numel(x);
pos = 1 + (n-1)*0.9;
lo = floor(pos);
hi = ceil(pos);
p = x(lo) + (pos-lo)*(x(hi)-x(lo));
end
