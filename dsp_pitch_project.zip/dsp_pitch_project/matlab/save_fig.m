function save_fig(fig, name)
try
    exportgraphics(fig, name, 'Resolution', 150);
catch
    saveas(fig, name);
end
close(fig);
end
