function [h, info] = design_qmf_prototype(N, alpha, ws)
%DESIGN_QMF_PROTOTYPE  (optional) Re-design the N-tap QMF prototype low-pass filter by minimising
%   phi = alpha*phi1 + (1-alpha)*phi2   (Eqs. 17-20 of Agrawal & Sahu 2013)
%   phi1: flatness of the overall distortion function, phi2: stop-band energy.
%   Needs fminunc (Optimization Toolbox); falls back to fminsearch (slow, less accurate).
%   run_qmf uses the stored coefficients in qmf_h0.csv, so this is only needed if you
%   want to redesign the filter.
if nargin < 1, N = 32; end
if nargin < 2, alpha = 0.9; end
if nargin < 3, ws = 0.6*pi; end
M = N/2;
w = linspace(0, pi, 2048);
n = 0:M-1;
A  = 2*cos(w(:)        * ((N-1)/2 - n));
A2 = 2*cos((pi - w(:)) * ((N-1)/2 - n));
stop = w(:) >= ws;
    function J = phi(hh)
        hh = hh(:);
        a = A*hh; b = A2*hh;
        phi1 = mean((1 - a.^2 - b.^2).^2) * pi;
        phi2 = mean(a(stop).^2) * (pi - ws);
        J = alpha*phi1 + (1-alpha)*phi2;
    end
% initial guess: Hamming-windowed sinc, cut-off pi/2
k = (0:N-1) - (N-1)/2;
s = ones(size(k)); nz = k ~= 0; s(nz) = sin(pi*0.5*k(nz)) ./ (pi*0.5*k(nz));
h0 = 0.5*s .* (0.54 - 0.46*cos(2*pi*(0:N-1)/(N-1)));
h0 = h0 / sum(h0);
x0 = h0(1:M)';
if exist('fminunc', 'file') == 2
    opts = optimoptions('fminunc', 'Display', 'off', 'MaxIterations', 5000, ...
        'MaxFunctionEvaluations', 200000, 'OptimalityTolerance', 1e-12);
    xo = fminunc(@phi, x0, opts);
else
    opts = optimset('MaxIter', 50000, 'MaxFunEvals', 500000, 'TolFun', 1e-14, 'TolX', 1e-12);
    xo = fminsearch(@phi, x0, opts);
end
h = [xo(:); flipud(xo(:))];
[pre, As] = qmf_metrics(h, ws);
info = struct('PRE_dB', pre, 'As_dB', As, 'N', N, 'alpha', alpha, 'ws_over_pi', ws/pi);
end
