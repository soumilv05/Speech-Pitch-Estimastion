function [t, f0, voiced] = track_pitch(x, fs, frame_ms, hop_ms, window, zpad, varargin)
%TRACK_PITCH  Frame-by-frame pitch track. Voicing = frame energy above a fraction
%   of the loud-frame (90th percentile) energy.
%   Options (name,value): 'energy_rel' (0.05), 'fmin' (60), 'fmax' (400), 'n_hps' (3)
p = inputParser;
addParameter(p, 'energy_rel', 0.05);
addParameter(p, 'fmin', 60);
addParameter(p, 'fmax', 400);
addParameter(p, 'n_hps', 3);
parse(p, varargin{:});
o = p.Results;
N = round(frame_ms*1e-3*fs);
hop = round(hop_ms*1e-3*fs);
nfft = round(N*zpad);
[frames, centers] = frame_signal(x, N, hop);
energy = mean(frames.^2, 1);
voiced = energy > o.energy_rel * pct90(energy);
f0 = nan(1, numel(energy));
if any(voiced)
    f0(voiced) = estimate_f0(frames(:,voiced), fs, window, nfft, o.fmin, o.fmax, o.n_hps);
end
voiced = voiced & ~isnan(f0);
t = centers / fs;
end
