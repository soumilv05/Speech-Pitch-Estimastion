function items = load_keele(folder)
%LOAD_KEELE  Load the Keele recordings (f1..f5, m1..m5) and ground-truth pitch.
d = dir(fullfile(folder, '*nw0000.wav'));
items = struct('name',{}, 'sex',{}, 'fs',{}, 'x',{}, 'gt',{});
for i = 1:numel(d)
    nm = d(i).name;
    if isempty(regexp(nm, '^[fm]\dnw0000\.wav$', 'once')), continue; end
    [x, fs] = audioread(fullfile(folder, nm));
    x = x(:,1);
    x = x / (max(abs(x)) + 1e-12);
    S = load(fullfile(folder, ['gt_' strrep(nm, '.wav', '.mat')]));
    items(end+1) = struct('name', nm(1:2), 'sex', upper(nm(1)), 'fs', fs, ...
                          'x', x(:), 'gt', S.gt(:)); %#ok<AGROW>
end
if isempty(items)
    error('No Keele files found in "%s". Put the "KEELE Database" folder next to the matlab folder.', folder);
end
end
