function run_synthetic(prefix)
%RUN_SYNTHETIC  Synthetic experiment: accuracy vs frame length, window, zero-padding, SNR.
if nargin < 1, prefix = 'synthetic'; end
FS = 16000;
frames = [10 20 30 40 60 80];
windows = {'boxcar','hamming','hann','blackman'};
zpads = [1 8];
snrs = [20 5];
seeds = 0:2;
rows = struct('snr_db',{},'frame_ms',{},'window',{},'zpad',{},'delta_f_Hz',{}, ...
    'bin_spacing_Hz',{},'rmse_Hz',{},'rmse_nongross_Hz',{},'gross_error_pct',{},'voicing_err_pct',{});
for si = 1:numel(snrs)
    snr = snrs(si);
    sig = cell(numel(seeds), 3);
    for k = 1:numel(seeds)
        [x, f0s, vs] = synth_speechlike(FS, 3.0, snr, 15, seeds(k));
        sig(k,:) = {x, f0s, vs};
    end
    for fm = frames
        for wi = 1:numel(windows)
            for zp = zpads
                r = zeros(numel(seeds), 4);
                N = round(fm*1e-3*FS);
                hop = round(10e-3*FS);
                for k = 1:numel(seeds)
                    [t, f0e, ve] = track_pitch(sig{k,1}, FS, fm, 10, windows{wi}, zp);
                    c = (0:numel(t)-1)*hop + floor(N/2) + 1;
                    r(k,:) = eval_basic(f0e, ve, sig{k,2}(c), sig{k,3}(c));
                end
                m = mean(r, 1, 'omitnan');
                rows(end+1) = struct('snr_db',snr,'frame_ms',fm,'window',windows{wi},'zpad',zp, ...
                    'delta_f_Hz',FS/N,'bin_spacing_Hz',FS/(N*zp),'rmse_Hz',m(1), ...
                    'rmse_nongross_Hz',m(2),'gross_error_pct',m(3),'voicing_err_pct',m(4)); %#ok<AGROW>
            end
        end
    end
end
T = struct2table(rows);
writetable(T, [prefix '.csv']);

% accuracy vs frame length (zero-pad x8)
fig = figure('Visible','off','Position',[100 100 1100 700]);
for j = 1:numel(snrs)
    for wi = 1:numel(windows)
        s = T(T.snr_db==snrs(j) & strcmp(T.window,windows{wi}) & T.zpad==8, :);
        subplot(2,2,j);   hold on; plot(s.frame_ms, s.rmse_Hz, 'o-', 'DisplayName', windows{wi});
        subplot(2,2,j+2); hold on; plot(s.frame_ms, s.gross_error_pct, 'o-', 'DisplayName', windows{wi});
    end
    subplot(2,2,j);   title(sprintf('Pitch RMSE, SNR = %d dB', snrs(j))); ylabel('RMSE (Hz)'); grid on;
    subplot(2,2,j+2); title(sprintf('Gross error rate, SNR = %d dB', snrs(j))); ylabel('Gross errors (%)');
    xlabel('Frame length (ms)'); grid on;
end
subplot(2,2,1); legend('Location','northeast');
save_fig(fig, [prefix '_accuracy_vs_frame.png']);

% zero-padding effect
fig = figure('Visible','off','Position',[100 100 600 400]); hold on;
for zp = zpads
    s = T(T.snr_db==20 & strcmp(T.window,'hamming') & T.zpad==zp, :);
    plot(s.frame_ms, s.rmse_Hz, 'o-', 'DisplayName', sprintf('zero-pad x%d', zp));
end
xlabel('Frame length (ms)'); ylabel('RMSE (Hz)'); grid on; legend;
title('Zero-padding vs. true resolution (Hamming, 20 dB)');
save_fig(fig, [prefix '_zeropad.png']);

% example contour
[x, f0s, vs] = synth_speechlike(FS, 3.0, 20, 15, 0);
[t, f0e, ve] = track_pitch(x, FS, 30, 10, 'hamming', 8);
N = round(30e-3*FS); hop = round(10e-3*FS);
c = (0:numel(t)-1)*hop + floor(N/2) + 1;
f0r = f0s(c); vr = vs(c);
fig = figure('Visible','off','Position',[100 100 800 400]); hold on;
plot(t, nanmask(f0r, vr), 'DisplayName', 'reference');
plot(t, nanmask(f0e, ve), '.', 'DisplayName', 'estimate');
xlabel('Time (s)'); ylabel('F0 (Hz)'); grid on; legend;
title('Synthetic signal: pitch track (30 ms, Hamming, zero-pad x8)');
save_fig(fig, [prefix '_contour.png']);

fprintf('%4s %6s %9s %3s %7s %7s %6s %6s\n', 'SNR','frame','window','zp','df(Hz)','RMSE','GER%','VDE%');
for i = 1:numel(rows)
    q = rows(i);
    if q.zpad == 8
        fprintf('%4d %6d %9s %3d %7.1f %7.2f %6.1f %6.1f\n', q.snr_db, q.frame_ms, q.window, ...
            q.zpad, q.delta_f_Hz, q.rmse_Hz, q.gross_error_pct, q.voicing_err_pct);
    end
end
fprintf('Saved %s.csv and %s_*.png\n', prefix, prefix);
end

function r = eval_basic(f_est, v_est, f_ref, v_ref)
% RMSE, RMSE without gross errors, gross error rate (%), voicing decision error (%)
both = v_est & v_ref;
if ~any(both), r = [NaN NaN NaN 100]; return; end
err = f_est(both) - f_ref(both);
gross = abs(err) > 0.2*f_ref(both);
rmse = sqrt(mean(err.^2));
if any(~gross), fine = sqrt(mean(err(~gross).^2)); else, fine = NaN; end
r = [rmse, fine, 100*mean(gross), 100*mean(v_est ~= v_ref)];
end

function y = nanmask(f, v)
y = f; y(~v) = NaN;
end
