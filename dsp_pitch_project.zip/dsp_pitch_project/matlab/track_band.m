function [t, f0, v, meta] = track_band(x_full, fs, x_low, levels, frame_ms, window, zpad)
%TRACK_BAND  Pitch track on the QMF low band. The voiced/unvoiced decision comes from the
%   FULL-BAND frame energy, so every level is scored on the same set of frames.
%   HPS order is limited so that all harmonics lie below the decimated Nyquist frequency.
FMIN = 50; FMAX = 400; hop_ms = 10; energy_rel = 0.05;
fs_l = fs / 2^levels;
N = round(frame_ms*1e-3*fs);  hop = round(hop_ms*1e-3*fs);
fr = frame_signal(x_full, N, hop);
en = mean(fr.^2, 1);
vmask = en > energy_rel * pct90(en);
n_hps = max(1, min(4, floor((fs_l/2) / FMAX)));
Nl = round(frame_ms*1e-3*fs_l);  hopl = round(hop_ms*1e-3*fs_l);
[frl, cl] = frame_signal(x_low, Nl, hopl);
n = min(size(frl,2), size(fr,2));
frl = frl(:,1:n);  vm = vmask(1:n);
nfft = Nl * zpad;
f0 = nan(1, n);
if any(vm)
    f0(vm) = estimate_f0(frl(:,vm), fs_l, window, nfft, FMIN, FMAX, n_hps);
end
v = vm & ~isnan(f0);
t = cl(1:n) / fs_l;
meta = struct('fs_level', fs_l, 'n_hps', n_hps, 'nfft', nfft);
end
