function run_qmf(folder, quick)
%RUN_QMF  QMF low-band pitch experiment (Agrawal & Sahu 2013 octave tree).
if nargin < 2, quick = false; end
here = fileparts(mfilename('fullpath'));
h = readmatrix(fullfile(here, 'qmf_h0.csv'));
h = h(:);
[pre, As] = qmf_metrics(h);
fprintf('QMF prototype (N=%d): PRE = %.4f dB, As = %.1f dB   (paper Table 1, N=32: PRE 0.009-0.05 dB, As 33-49 dB)\n', ...
    numel(h), pre, As);

% filter plot
w = linspace(0, pi, 2048);
H0 = abs(qmf_amp(h, w));  H1 = abs(qmf_amp(h, pi - w));  T = 0.5*(H0.^2 + H1.^2);
fig = figure('Visible','off','Position',[100 100 1100 400]);
subplot(1,2,1); plot(w/pi, 20*log10(H0+1e-12), 'DisplayName', '|H0| (low-pass)'); hold on;
plot(w/pi, 20*log10(H1+1e-12), 'DisplayName', '|H1| = |H0(-z)| (high-pass)');
ylim([-80 5]); grid on; legend; xlabel('Normalised frequency (x pi rad/sample)'); ylabel('Magnitude (dB)');
title(sprintf('QMF analysis filters, N=%d', numel(h)));
subplot(1,2,2); plot(w/pi, 10*log10(T)); grid on;
xlabel('Normalised frequency (x pi rad/sample)'); ylabel('|T| (dB)');
title(sprintf('Overall distortion: PRE = %.3f dB, As = %.1f dB', pre, As));
save_fig(fig, 'qmf_filter.png');

items = load_keele(folder);
if quick
    levels = [0 2]; frames = [30 60];
else
    levels = 0:3; frames = [20 30 40 60 80];
end
cache = cell(numel(items), numel(levels));
for i = 1:numel(items)
    for li = 1:numel(levels)
        cache{i,li} = qmf_lowband(items(i).x, h, levels(li));
    end
end
sexes = [items.sex];
rows = [];
for li = 1:numel(levels)
    L = levels(li);
    for fm = frames
        per = zeros(numel(items), 4);
        for i = 1:numel(items)
            [t, f0, v, meta] = track_band(items(i).x, items(i).fs, cache{i,li}, L, fm, 'hamming', 8);
            per(i,:) = score_keele(items(i), t, f0, v);
        end
        r = struct('level',L, 'band_Hz', items(1).fs/2^(L+1), 'fs_level', meta.fs_level, ...
            'hps_order', meta.n_hps, 'frame_ms', fm, 'fft_len', meta.nfft, ...
            'rmse_Hz', mean(per(:,1),'omitnan'), 'rmse_fine_Hz', mean(per(:,2),'omitnan'), ...
            'gross_error_pct', mean(per(:,3),'omitnan'), ...
            'gross_error_pct_F', mean(per(sexes=='F',3),'omitnan'), ...
            'gross_error_pct_M', mean(per(sexes=='M',3),'omitnan'));
        rows = [rows r]; %#ok<AGROW>
        fprintf('  level %d, %g ms done\r', L, fm);
    end
end
fprintf('\n');
writetable(struct2table(rows), 'qmf_lowband_results.csv');

fprintf('\n%3s %6s %6s %3s %6s %6s | %6s %5s %6s %6s %6s   (Hamming, zero-pad x8)\n', ...
    'lvl','band','fs','HPS','frame','FFT','RMSE','fine','GER%','GER-F','GER-M');
for i = 1:numel(rows)
    r = rows(i);
    fprintf('%3d %6d %6d %3d %6g %6d | %6.1f %5.1f %6.1f %6.1f %6.1f\n', r.level, r.band_Hz, ...
        r.fs_level, r.hps_order, r.frame_ms, r.fft_len, r.rmse_Hz, r.rmse_fine_Hz, ...
        r.gross_error_pct, r.gross_error_pct_F, r.gross_error_pct_M);
end

Tq = struct2table(rows);
fig = figure('Visible','off','Position',[100 100 1500 400]);
for li = 1:numel(levels)
    L = levels(li);
    s = Tq(Tq.level == L, :);
    lab = sprintf('level %d: 0-%d Hz', L, s.band_Hz(1));
    subplot(1,3,1); hold on; plot(s.frame_ms, s.gross_error_pct, 'o-', 'DisplayName', lab);
    subplot(1,3,2); hold on; plot(s.frame_ms, s.rmse_fine_Hz, 'o-', 'DisplayName', lab);
end
mid = max(Tq.frame_ms(Tq.frame_ms <= 40));
s = Tq(Tq.frame_ms == mid, :);
subplot(1,3,3); hold on;
plot(s.level, s.gross_error_pct_F, 'o-', 'DisplayName', 'female');
plot(s.level, s.gross_error_pct_M, 'o--', 'DisplayName', 'male');
subplot(1,3,1); title('Gross error rate vs frame length'); ylabel('Gross errors (%)'); xlabel('Frame length (ms)');
subplot(1,3,2); title('Fine RMSE (gross errors excluded)'); ylabel('RMSE (Hz)'); xlabel('Frame length (ms)');
subplot(1,3,3); title(sprintf('Gross errors vs QMF level (%g ms frames)', mid)); ylabel('Gross errors (%)');
xlabel('QMF tree level (0 = full band)'); xticks(levels);
for k = 1:3, subplot(1,3,k); grid on; legend('Location','best'); end
save_fig(fig, 'qmf_lowband_summary.png');
fprintf('Saved: qmf_filter.png, qmf_lowband_results.csv, qmf_lowband_summary.png\n');
end
