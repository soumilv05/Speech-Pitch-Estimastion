function [x, f0, voiced] = synth_speechlike(fs, dur, snr_db, n_harm, seed)
%SYNTH_SPEECHLIKE  Harmonic signal with gliding F0 (90-190 Hz), one unvoiced gap and noise.
%   Same construction as the Python version; the random noise differs (different RNG).
rng(seed);
t = (0:floor(dur*fs)-1) / fs;
f0 = 140 + 50*sin(2*pi*0.8*t);
voiced = ~((t > 1.2) & (t < 1.5));
phase = 2*pi*cumsum(f0)/fs;
x = zeros(size(t));
for k = 1:n_harm
    if k*max(f0) >= fs/2, break; end
    x = x + (1/k)*sin(k*phase);
end
x = x .* voiced;
sig_pow = mean(x(voiced).^2);
x = x + randn(size(t)) * sqrt(sig_pow / 10^(snr_db/10));
end
