function w = get_win(name, N)
%GET_WIN  Periodic window (matches scipy.signal.get_window). No toolbox needed.
n = (0:N-1)';
switch lower(name)
    case {'boxcar','rect','rectangular'}
        w = ones(N,1);
    case 'hamming'
        w = 0.54 - 0.46*cos(2*pi*n/N);
    case {'hann','hanning'}
        w = 0.5 - 0.5*cos(2*pi*n/N);
    case 'blackman'
        w = 0.42 - 0.5*cos(2*pi*n/N) + 0.08*cos(4*pi*n/N);
    otherwise
        error('Unknown window: %s', name);
end
end
