function run_keele(folder, quick)
%RUN_KEELE  Evaluate the FFT/HPS tracker on the Keele database.
%   Sweep: frame length x window x zero-padding, mean over the 10 speakers.
if nargin < 2, quick = false; end
FMIN = 50; FMAX = 400; NHPS = 4;
items = load_keele(folder);
fprintf('Loaded %d speakers (%d F, %d M)\n', numel(items), sum([items.sex]=='F'), sum([items.sex]=='M'));
if quick
    frames = [20 40 60]; windows = {'hamming','hann'}; zpads = 8;
else
    frames = [10 20 30 40 60 80 100 120];
    windows = sort({'boxcar','hamming','hann','blackman'});
    zpads = [1 8];
end
rows = struct('speaker',{},'sex',{},'frame_ms',{},'window',{},'zpad',{},'delta_f_Hz',{}, ...
    'rmse_Hz',{},'rmse_fine_Hz',{},'gross_error_pct',{},'voicing_err_pct',{});
total = numel(frames)*numel(windows)*numel(zpads); done = 0;
for fm = frames
    for wi = 1:numel(windows)
        for zp = zpads
            for it = items
                [t, f0, v] = track_pitch(it.x, it.fs, fm, 10, windows{wi}, zp, ...
                    'fmin', FMIN, 'fmax', FMAX, 'n_hps', NHPS);
                r = score_keele(it, t, f0, v);
                N = round(fm*1e-3*it.fs);
                rows(end+1) = struct('speaker',it.name,'sex',it.sex,'frame_ms',fm,'window',windows{wi}, ...
                    'zpad',zp,'delta_f_Hz',it.fs/N,'rmse_Hz',r(1),'rmse_fine_Hz',r(2), ...
                    'gross_error_pct',r(3),'voicing_err_pct',r(4)); %#ok<AGROW>
            end
            done = done + 1;
            fprintf('  config %d/%d\r', done, total);
        end
    end
end
fprintf('\n');
Tr = struct2table(rows);
writetable(Tr, 'keele_results_per_speaker.csv');

% aggregate: mean over speakers (equal weight) for all / F / M
metrics = {'rmse_Hz','rmse_fine_Hz','gross_error_pct','voicing_err_pct'};
tags = {'all','F','M'};
agg = [];
for fm = frames
    for wi = 1:numel(windows)
        for zp = zpads
            sel = Tr.frame_ms==fm & strcmp(Tr.window,windows{wi}) & Tr.zpad==zp;
            a = struct('frame_ms',fm,'window',windows{wi},'zpad',zp, ...
                'delta_f_Hz',Tr.delta_f_Hz(find(sel,1)));
            for ti = 1:3
                if ti == 1, g = sel; else, g = sel & strcmp(Tr.sex, tags{ti}); end
                for mi = 1:numel(metrics)
                    a.([metrics{mi} '_' tags{ti}]) = mean(Tr.(metrics{mi})(g), 'omitnan');
                end
            end
            agg = [agg a]; %#ok<AGROW>
        end
    end
end
Ta = struct2table(agg);
writetable(Ta, 'keele_results_summary.csv');

fprintf('\n%6s %9s %6s | %6s %5s %6s %6s %6s %5s   (zero-pad x8, mean over speakers)\n', ...
    'frame','window','df','RMSE','fine','GER%','GER-F','GER-M','VDE%');
for i = 1:numel(agg)
    a = agg(i);
    if a.zpad == 8
        fprintf('%6g %9s %6.1f | %6.1f %5.1f %6.1f %6.1f %6.1f %5.1f\n', a.frame_ms, a.window, a.delta_f_Hz, ...
            a.rmse_Hz_all, a.rmse_fine_Hz_all, a.gross_error_pct_all, a.gross_error_pct_F, ...
            a.gross_error_pct_M, a.voicing_err_pct_all);
    end
end

% ---- plots ----
fig = figure('Visible','off','Position',[100 100 1100 800]);
for wi = 1:numel(windows)
    s = Ta(strcmp(Ta.window,windows{wi}) & Ta.zpad==8, :);
    subplot(2,2,1); hold on; plot(s.frame_ms, s.gross_error_pct_all, 'o-', 'DisplayName', windows{wi});
    subplot(2,2,2); hold on; plot(s.frame_ms, s.rmse_fine_Hz_all, 'o-', 'DisplayName', windows{wi});
end
subplot(2,2,1); title('Gross error rate vs frame length (all speakers, zero-pad x8)'); ylabel('Gross errors (%)');
subplot(2,2,2); title('Fine RMSE (gross errors excluded)'); ylabel('RMSE (Hz)');
if any(strcmp(windows,'hamming'))
    s = Ta(strcmp(Ta.window,'hamming') & Ta.zpad==8, :);
    subplot(2,2,3); hold on;
    plot(s.frame_ms, s.gross_error_pct_F, 'o-', 'DisplayName', 'female');
    plot(s.frame_ms, s.gross_error_pct_M, 'o--', 'DisplayName', 'male');
    title('Female vs male gross error rate (Hamming, x8)'); ylabel('Gross errors (%)');
    subplot(2,2,4); hold on;
    for zp = zpads
        s = Ta(strcmp(Ta.window,'hamming') & Ta.zpad==zp, :);
        plot(s.frame_ms, s.rmse_fine_Hz_all, 'o-', 'DisplayName', sprintf('zero-pad x%d', zp));
    end
    title('Zero-padding vs fine RMSE (Hamming)'); ylabel('RMSE (Hz)');
end
for k = 1:4
    subplot(2,2,k); xlabel('Frame length (ms)'); grid on; legend('Location','best');
end
save_fig(fig, 'keele_summary.png');

cand = Ta(Ta.zpad==8, :);
[~, bi] = min(cand.gross_error_pct_all);
best = cand(bi, :);
fig = figure('Visible','off','Position',[100 100 1000 600]);
names = {'f2','m2'};
for k = 1:2
    idx = find(strcmp({items.name}, names{k}), 1);
    if isempty(idx), idx = k; end
    it = items(idx);
    [t, f0, v] = track_pitch(it.x, it.fs, best.frame_ms, 10, best.window{1}, 8, ...
        'fmin', FMIN, 'fmax', FMAX, 'n_hps', NHPS);
    tg = 0.0128 + 0.010*(0:numel(it.gt)-1);
    ref = it.gt; ref(ref <= 0) = NaN;
    subplot(2,1,k); hold on;
    s1 = tg < 8; plot(tg(s1), ref(s1), '-', 'LineWidth', 2, 'DisplayName', 'reference (Keele)');
    s2 = t < 8;  fe = f0; fe(~v) = NaN;
    plot(t(s2), fe(s2), '.', 'MarkerSize', 8, 'DisplayName', 'estimate');
    title(sprintf('%s: %g ms, %s, zero-pad x8', it.name, best.frame_ms, best.window{1}));
    ylabel('F0 (Hz)'); grid on; legend;
end
xlabel('Time (s)');
save_fig(fig, 'keele_contours.png');
fprintf('\nBest (lowest gross error rate): %g ms, %s, zero-pad x8 -> GER %.1f%%, fine RMSE %.1f Hz\n', ...
    best.frame_ms, best.window{1}, best.gross_error_pct_all, best.rmse_fine_Hz_all);
fprintf('Saved: keele_results_per_speaker.csv, keele_results_summary.csv, keele_summary.png, keele_contours.png\n');
end
