function [frames, centers] = frame_signal(x, N, hop)
%FRAME_SIGNAL  Split x into overlapping frames (one frame per column).
%   centers = 0-based sample index of each frame centre (time = centers/fs).
x = x(:);
n = 1 + floor((numel(x) - N) / hop);
idx = (1:N)' + hop*(0:n-1);
frames = x(idx);
centers = (0:n-1)*hop + floor(N/2);
end
