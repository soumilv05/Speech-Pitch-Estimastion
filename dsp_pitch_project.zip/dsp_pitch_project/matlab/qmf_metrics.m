function [pre_dB, As_dB] = qmf_metrics(h, ws)
%QMF_METRICS  PRE and stop-band edge attenuation As, as in Eq. (15) of Agrawal & Sahu.
if nargin < 2, ws = 0.6*pi; end
w = linspace(0, pi, 2048);
a = qmf_amp(h, w);
b = qmf_amp(h, pi - w);
T = a.^2 + b.^2;
pre_dB = 10*log10(max(T)) - 10*log10(min(T));
As_dB = -20*log10(abs(interp1(w, a, ws)));
end
