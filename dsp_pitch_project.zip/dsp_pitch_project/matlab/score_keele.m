function r = score_keele(item, t, f0, v)
%SCORE_KEELE  [rmse, rmse_fine, gross_error_pct, voicing_error_pct] against Keele ground truth.
%   Reference frame i (0-based) is centred at i*10 ms + 12.8 ms. Negative reference values
%   (uncertain frames) are excluded. Gross error: |est-ref| > 20 % of ref.
idx = round((t - 0.0128) / 0.010);          % 0-based reference frame index
ok = idx >= 0 & idx < numel(item.gt);
f0 = f0(ok); v = v(ok); idx = idx(ok);
gr = item.gt(idx + 1);
gr = gr(:)';
keep = gr >= 0;
refv = gr > 0;
f0 = f0(keep); v = v(keep); gr = gr(keep); refv = refv(keep);
both = v & refv;
if ~any(both)
    r = [NaN NaN NaN NaN];
    return;
end
err = f0(both) - gr(both);
gross = abs(err) > 0.2*gr(both);
rmse = sqrt(mean(err.^2));
if any(~gross)
    fine = sqrt(mean(err(~gross).^2));
else
    fine = NaN;
end
r = [rmse, fine, 100*mean(gross), 100*mean(v ~= refv)];
end
