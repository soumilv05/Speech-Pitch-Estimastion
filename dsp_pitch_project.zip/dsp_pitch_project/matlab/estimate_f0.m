function [f0, prom] = estimate_f0(frames, fs, window, nfft, fmin, fmax, n_hps)
%ESTIMATE_F0  Harmonic product spectrum on windowed, zero-padded FFT magnitude,
%   with parabolic interpolation around the peak. frames is N x n (one per column).
%   Returns row vectors f0 (Hz, NaN if no estimate) and peak prominence.
N = size(frames,1);
n = size(frames,2);
if isempty(nfft), nfft = N; end
w = get_win(window, N);
f0 = nan(1,n);
prom = zeros(1,n);
df = fs/nfft;                          % bin spacing (Hz)
nbin = floor(nfft/2) + 1;
L = floor(nbin/n_hps);
lo = max(ceil(fmin/df), 1);            % bin numbers below are 0-based
hi = min(floor(fmax/df), L-2);
if hi <= lo, return; end
chunk = max(1, floor(4e6/nfft));       % limit memory use
for c0 = 1:chunk:n
    cols = c0:min(n, c0+chunk-1);
    m = numel(cols);
    F = frames(:,cols);
    F = (F - mean(F,1)) .* w;
    Y = abs(fft(F, nfft, 1));
    X = Y(1:nbin,:);
    hps = X(1:L,:);
    for h = 2:n_hps
        tmp = X(1:h:end,:);
        hps = hps .* tmp(1:L,:);
    end
    seg = hps(lo+1:hi+1,:);
    [~, im] = max(seg, [], 1);
    k = lo + im - 1;                   % 0-based bin of the peak
    ra = log(hps(sub2ind(size(hps), k,   1:m)) + 1e-30);   % bin k-1
    rb = log(hps(sub2ind(size(hps), k+1, 1:m)) + 1e-30);   % bin k
    rc = log(hps(sub2ind(size(hps), k+2, 1:m)) + 1e-30);   % bin k+1
    den = ra - 2*rb + rc;
    delta = zeros(1,m);
    nz = den ~= 0;
    delta(nz) = 0.5*(ra(nz) - rc(nz)) ./ den(nz);
    delta = min(max(delta, -1), 1);
    f0(cols) = (k + delta) * df;
    prom(cols) = hps(sub2ind(size(hps), k+1, 1:m)) ./ (median(seg,1) + 1e-30);
end
end
