% RUN_ALL  Run the whole project in MATLAB / MATLAB Online.
%   1. Upload the project folder (keep "matlab" and "KEELE Database" side by side).
%   2. Open this file, set quick = true for a fast check (about a minute), then run it.
%   Results are written to the folder "results_matlab" next to "matlab".
quick = false;

here = fileparts(mfilename('fullpath'));
addpath(here);
data = fullfile(here, '..', 'KEELE Database');
out  = fullfile(here, '..', 'results_matlab');
if ~exist(data, 'dir')
    error('Cannot find "KEELE Database" at %s. Keep it next to the matlab folder.', data);
end
if ~exist(out, 'dir'), mkdir(out); end
startdir = pwd;
cleanup = onCleanup(@() cd(startdir));
cd(out);
tic;
fprintf('=== 1/3  Synthetic experiments (known ground truth) ===\n');
run_synthetic('synthetic');
fprintf('\n=== 2/3  Keele evaluation (frame length x window x zero-padding) ===\n');
run_keele(data, quick);
fprintf('\n=== 3/3  QMF low-band experiment ===\n');
run_qmf(data, quick);
fprintf('\nDone in %.0f s. Results are in: %s\n', toc, out);
