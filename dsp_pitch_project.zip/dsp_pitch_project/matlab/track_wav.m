function track_wav(path, frame_ms)
%TRACK_WAV  Pitch-track your own recording:  track_wav('speech.wav', 40)
%   Saves pitch_track.csv and pitch_track.png in the current folder.
if nargin < 2, frame_ms = 40; end
[x, fs] = audioread(path);
x = mean(x, 2);
x = x / (max(abs(x)) + 1e-12);
[t, f0, v] = track_pitch(x, fs, frame_ms, 10, 'hamming', 8, 'fmin', 50, 'n_hps', 4);
T = table(t(:), f0(:), double(v(:)), 'VariableNames', {'time_s','f0_Hz','voiced'});
writetable(T, 'pitch_track.csv');
fig = figure('Visible','off','Position',[100 100 900 500]);
subplot(2,1,1); plot((0:numel(x)-1)/fs, x, 'LineWidth', 0.5); ylabel('Amplitude');
subplot(2,1,2); fe = f0; fe(~v) = NaN; plot(t, fe, '.'); ylabel('F0 (Hz)'); xlabel('Time (s)'); grid on;
save_fig(fig, 'pitch_track.png');
fprintf('Saved pitch_track.csv and pitch_track.png\n');
end
